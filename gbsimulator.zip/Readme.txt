           Gunbound Simulator (ver 1.2)
                    By Yoyobuae


Instruccions:

1. Run the executable.

2. A confing menu is displayed.

   - Display Modes:Try changing to diferent display modes
                   if the Simulator runs slow.
   - Select Map: Select which map is simulated, only 3
                 GB original maps are included for now.
                 'Flat Map' is a absolutely flat map
                 without land destruction. Good for making
                 tables.
   - Simulator Options: Select if wind changes randomly when
                        a certain amount of turns go by or
                        choose a fixed wind and angle.

3. You will see the familiar Gunbound aim in the center. 
   The display area is 800x600 pixels (stretched for display mode 1)
   just as in Gunbound, this area is divided in eights horizontally,
   each line in the grid indicates a 100 pixel separation, an eight of
   a screen.

4. You can change the angle and shooting direction of the shot
   with the arrow keys, left and right changes the direction,
   and up and down the angle.

5. You can change the shooting power with keypad + an -.

6. Finally you shoot with the "f" key.

7. To close the program press the "c" key or 'Esc'.
   
   
Note:
   You'll notice that when you move the angle the entire 
   aim rotates, this is to simulate your entire bot
   changing it's angle to be able to access higher angles, I 
   realized in my calculations that Trico's shot 2 starting 
   angle depends on the angle of Trico itself.  That's why 
   I included this feature.
   
Gunbound is Copyright of Softnyx.